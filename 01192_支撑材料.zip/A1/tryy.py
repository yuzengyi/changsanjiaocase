order_numbers = []
dingdan = 2
order_numbers.append(str(dingdan))
print(order_numbers)